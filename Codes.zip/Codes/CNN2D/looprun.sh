#!/bin/bash
pwd; hostname; date

## code
#model='cnn2d'
model='effnet7'
#model='resnet152'

## Fold
k=4

## parameters
batch_size=(16 32)
#batch_size=(32)
pat=(6)
#train_size=(1000)
train_size=(100000)

## input files

# Iterate over each combination of parameters
for bs in "${batch_size[@]}"; do
    for p in "${pat[@]}"; do
        for ts in "${train_size[@]}"; do

            for q in $(seq 0 $(($k))) ; do
                # Create the folder structure
                folder_name="all_jobs/batchsize_${bs}/pat_${p}/trainsize_${ts}/fold_${q}/"
                mkdir -p "$folder_name"
                echo "Created folder: $folder_name"

                ## move the exe file to the directory
                cp "${model}.py" $folder_name

                ## move the slurm runner to the directory
                cp "${model}_run.sh" $folder_name

                if [ -d "$folder_name" ]; then
                        echo "Running $model in $folder_name"
			(cd "$folder_name" && sbatch "${model}_run.sh" "${model}.py" $bs $p $ts $q )
                else
                    	echo "Directory $folder_name not found."

		fi
            done

        done
    done
done



