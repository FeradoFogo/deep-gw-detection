# -*- coding: utf-8 -*
#----------------------------------------------------------------------------------------------------------
## Import the libraries
import numpy as np
import pandas as pd
from glob import glob

import random
import os
import sys

from scipy.signal import welch
from scipy.interpolate import interp1d
from scipy.signal import butter, filtfilt
from scipy.signal import get_window

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.data import Subset
from torch.utils.data import Dataset
from tqdm import tqdm

from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import CosineAnnealingLR
from sklearn.metrics import roc_curve, auc

from scipy.signal import fftconvolve

#device = torch.device("cpu")
device = torch.device("cuda")
#print(torch.cuda.is_available())

import torch
from torch.utils.data import DataLoader, Subset
from torch.utils.data.dataset import random_split



### Call training data ###
labels = pd.read_csv("/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/training_labels.csv")
# Building a dataframe with paths and IDs of .npy files
path = "/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/train/"

#fonti007/gw_kaggle/train
paths = glob(path + "*/*/*/*")

training_labels = labels

training_paths = glob(path + "*/*/*/*")
#print(training_paths)

ids = [path.split("/")[-1].split(".")[0] for path in training_paths]
paths_df = pd.DataFrame({"path":training_paths, "id": ids})
train_data = pd.merge(left=training_labels, right=paths_df, on="id")


"""## Clean the data"""

## Def utily functions
def whiten(strain, dt, method='cu'):
    # Apply a window function
    if method == 'hanning':
        window = np.hanning(len(strain))
    elif method == 'hamming':
        window = np.hamming(len(strain))
    elif method == 'blackman':
        window = np.blackman(len(strain))
    else:
        window = np.ones(len(strain))

    # Windowed strain
    windowed_strain = strain * window

    # Zero-padding
    padded_strain = np.pad(windowed_strain, (len(strain)//2,), 'constant')

    # Estimate the power spectral density (PSD)
    freqs, Pxx = welch(padded_strain, fs=1/dt, nperseg=4*fs)

    # Interpolate the PSD to match the data length
    psd = interp1d(freqs, Pxx)

    # Fourier Transform of the padded data
    strain_ft = np.fft.rfft(padded_strain)

    # Frequency array
    freqs = np.fft.rfftfreq(len(padded_strain), dt)

    # Whiten the data
    white_strain = strain_ft / np.sqrt(psd(freqs))
    white_strain = np.fft.irfft(white_strain, n=len(padded_strain))

    # Remove padding
    white_strain = white_strain[len(strain)//2:-len(strain)//2]

    return white_strain
    
    
## Define class to organize and clean the data (Q-transform at the end!)
class G2NetDataset(Dataset):
    def __init__(self, dataframe, base_path, fs, lowcut, highcut):
        self.dataframe = dataframe
        self.base_path = base_path
        self.fs = fs
        self.lowcut = lowcut
        self.highcut = highcut

    def __len__(self):
        return len(self.dataframe)

    def bandpass_filter(self, data):
        nyq = 0.5 * self.fs
        low = self.lowcut / nyq
        high = self.highcut / nyq
        b, a = butter(4, [low, high], btype='band')
        normalization = np.sqrt((high-low))
        return filtfilt(b, a, data)/normalization

    def preprocess_data(self, data):
        window = get_window(('tukey', 0.125), data.shape[1])
        data_windowed = data * window
        whitened_data = np.array([whiten(d, 1.0/fs) for d in data_windowed])
        filtered_data = np.array([self.bandpass_filter(d) for d in whitened_data])
        return filtered_data


    def __getitem__(self, idx):
        file_id = self.dataframe.iloc[idx]['id']
        path = f"{self.base_path}/{file_id[0]}/{file_id[1]}/{file_id[2]}/{file_id}.npy"
        data = np.load(path)
        data = self.preprocess_data(data)
        label = self.dataframe.iloc[idx]['target']
        return torch.from_numpy(data).float(), torch.tensor(label).float()

print('---------------------------------------------')
print('--------- Cleaning data class ---------------')


print('---------------------------------------------')
print('--------- Model defined ---------------')


class GeM(nn.Module):
    '''
    Code modified from the 2d code in
    https://amaarora.github.io/2020/08/30/gempool.html
    '''
    def __init__(self, kernel_size=8, p=3, eps=1e-6):
        super(GeM,self).__init__()
        self.p = nn.Parameter(torch.ones(1)*p)
        self.kernel_size = kernel_size
        self.eps = eps

    def forward(self, x):
        return self.gem(x, p=self.p, eps=self.eps)
        
    def gem(self, x, p=3, eps=1e-6):
        return F.avg_pool1d(x.clamp(min=eps).pow(p), self.kernel_size).pow(1./p)
        
    def __repr__(self):
        return self.__class__.__name__ +  '(' + 'p=' + '{:.4f}'.format(self.p.data.tolist()[0]) +  ', ' + 'eps=' + str(self.eps) + ')'


### CNN 1d


class CNN1d(nn.Module):
    """1D convolutional neural network. Classifier of the gravitational waves.
    Architecture from there https://journals.aps.org/prl/pdf/10.1103/PhysRevLett.120.141103
    """

    def __init__(self, debug=False):
        super().__init__()
        self.cnn1 = nn.Sequential(
            nn.Conv1d(3, 64, kernel_size=64),
            nn.BatchNorm1d(64),
            nn.SiLU(),
        )
        self.cnn2 = nn.Sequential(
            nn.Conv1d(64, 64, kernel_size=32),
            GeM(kernel_size=8),
            nn.BatchNorm1d(64),
            nn.SiLU(),
        )
        self.cnn3 = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=32),
            nn.BatchNorm1d(128),
            nn.SiLU(),
        )
        self.cnn4 = nn.Sequential(
            nn.Conv1d(128, 128, kernel_size=16),
            GeM(kernel_size=6),
            nn.BatchNorm1d(128),
            nn.SiLU(),
        )
        self.cnn5 = nn.Sequential(
            nn.Conv1d(128, 256, kernel_size=16),
            nn.BatchNorm1d(256),
            nn.SiLU(),
        )
        self.cnn6 = nn.Sequential(
            nn.Conv1d(256, 256, kernel_size=16),
            GeM(kernel_size=4),
            nn.BatchNorm1d(256),
            nn.SiLU(),
        )
        self.fc1 = nn.Sequential(
            nn.Linear(256 * 11, 64),
            nn.BatchNorm1d(64),
            nn.Dropout(0.25),
            nn.SiLU(),
        )
        self.fc2 = nn.Sequential(
            nn.Linear(64, 64),
            nn.BatchNorm1d(64),
            nn.Dropout(0.25),
            nn.SiLU(),
        )
        self.fc3 = nn.Sequential(
            nn.Linear(64, 1),
        )
        self.debug = debug

    def forward(self, x, pos=None):
        x = self.cnn1(x)
        x = self.cnn2(x)
        x = self.cnn3(x)
        x = self.cnn4(x)
        x = self.cnn5(x)
        x = self.cnn6(x)
        x = x.flatten(start_dim=1)
        x = self.fc1(x)
        x = self.fc2(x)
        x = self.fc3(x)
        return x


"""
Evaluating the model

"""
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import roc_curve, auc, f1_score, precision_score, recall_score, confusion_matrix

save_path = "/panfs/jay/groups/6/csci5527/fonti007/feradofogao/"
modelo = 'CNN1d-v4-cuda'

### Load trained model ###
weights_folder = "/panfs/jay/groups/6/csci5527/fonti007/CNN1D-v4_results/" 
fold_list = range(5)
batch_list = [16,50,8]
pat_list = [1,3,7]
train_size_list = [358398,100000]

def evaluate_test_model(test_loader,device,fold,batch_size,pat):
    model = CNN1d()
    model.to(device)
    weight_path = weights_folder + "CNN1D_cluster" + "_fold" + str(fold) + "_batch" + str(batch_size) +"_pat" + str(pat) + ".pth"
   # model.load_state_dict(torch.load(weights_path), map_location=torch.device("cpu"))
    model.load_state_dict(torch.load(weight_path, map_location=torch.device('cuda')))
    model.eval()
    criterion = nn.BCEWithLogitsLoss()
    running_loss = 0.0
    total = 0
    correct = 0
    all_labels = []
    all_probabilities = []
    all_predictions = []

    with torch.no_grad():
        for inputs, labels in test_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.squeeze(), labels)
            running_loss += loss.item()

            probabilities = torch.sigmoid(outputs).squeeze().cpu().numpy()
            preds = (probabilities > 0.5).astype(np.float32)
            all_labels.extend(labels.cpu().numpy())
            all_probabilities.extend(probabilities)
            all_predictions.extend(preds)

            total += labels.size(0)
            correct += (preds == labels.cpu().numpy()).sum()

    avg_loss = running_loss / len(test_loader)
    accuracy = correct / total
    
    all_predictions = np.array(all_predictions)
    all_labels = np.array(all_labels)
    f1 = f1_score(all_labels, all_predictions)
    precision = precision_score(all_labels, all_predictions)
    recall = recall_score(all_labels, all_predictions)
    cm = confusion_matrix(all_labels, all_predictions)
   
    # Calculate ROC curve and AUROC
    fpr, tpr, _ = roc_curve(all_labels, all_probabilities)
    auroc = auc(fpr, tpr)
    
    np.savetxt( save_path+ modelo+ '-val_metrics_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), [avg_loss, accuracy, auroc,f1,precision,recall])
    
    np.savetxt( save_path+ modelo+ '-all_predictions_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_predictions)
    np.savetxt( save_path+ modelo+ '-all_labels_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_labels)

    np.savetxt( save_path+ modelo+ '-all_probabilities_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_probabilities)
    np.savetxt( save_path+ modelo+ '-fpr_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), fpr)                        
    np.savetxt( save_path+ modelo+ '-tpr_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), tpr)

    np.savetxt( save_path+ modelo+ '-cm_fold%d_batch%d_pat%d.txt'%(fold, batch_size,pat), cm)
    
   # return avg_loss, accuracy, all_predictions, all_probabilities, all_labels, fpr, tpr, auroc, f1, precision, recall, cm

# Create the test dataset
# Setup parameters
base_path = "/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/train"
fs = 2048  # Sampling frequency
lowcut = 25.0  # Low cut-off frequency
highcut = 1000.0  # High cut-off frequency
test_batch_size = 100
#batch_size = batch_size_arg
#modelo = 'CNN1D'


# Create the full dataset
full_train_dataset = G2NetDataset(dataframe=train_data, base_path=base_path, fs=fs, lowcut=lowcut, highcut=highcut)

# Calculate the index for splitting (80% for training + validation, 20% for testing)
split_index = int(len(train_data) * 0.8)

# Split the data indices for non-test and test
#test_indices = list(range(split_index, len(train_data)))
test_indices = list(range(len(train_data) -50000, len(train_data)))
test_subset = Subset(full_train_dataset, test_indices)

# Create a DataLoader for the test data
test_loader = DataLoader(test_subset, batch_size=test_batch_size, shuffle=False, num_workers=1)

#print(weight_path)
#print(test_indices)

#avg_loss, accuracy, all_predictions, all_probabilities, all_labels, fpr, tpr, auroc, f1, precision, recall, cm = evaluate_test_model(test_loader, device,fold_list[0],batch_list[0],pat_list[0])

for batch in batch_list:
     evaluate_test_model(test_loader, device,fold_list[3],batch,pat_list[1])

print("###### Evaluation finished #####")
