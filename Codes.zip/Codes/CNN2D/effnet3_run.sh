#!/bin/bash -i
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --mem=15gb                   # Job memory request
#SBATCH -p a100-8                      # Partition name
#SBATCH --gres=gpu:a100:1
#SBATCH --time=24:00:00              # Time limit hrs:min:sec
#SBATCH -o slurm_%j.out
#SBATCH -e slurm_%j.err

#source /panfs/roc/msisoft/anaconda/anaconda3-2018.12/etc/profile.d/conda.sh
#module load  python3/3.9.3_anaconda2021.11_mamba
#conda activate pytorch_env
#
#cd /panfs/jay/groups/20/perkins/danta008

#export PATH=/panfs/jay/groups/20/perkins/danta008/.conda/envs/torch_env/bin:$PATH

#cd /panfs/jay/groups/6/csci5527/fonti007/vitor/KFODE_TRANS

export PATH=/home/perkinsn/danta008/.conda/envs/torch_env/bin:$PATH

echo $2
echo $3
echo $4
echo $5
echo '---------------'


python $1 $2 $3 $4 $5
