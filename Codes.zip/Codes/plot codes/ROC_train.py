#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 20 20:22:07 2023

@author: vitor
"""


from numba import njit
import time
import numpy as np
import glob
import os
import re
import sys
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition,mark_inset)
import matplotlib.pyplot as plt
import matplotlib.ticker
from matplotlib import rc
from scipy.ndimage import uniform_filter1d
from scipy import optimize
import matplotlib.lines as mlines
import pandas as pd

rc('font',**{'family':'serif','serif':['Helvetica']})
# for Palatino and other serif fonts use:
# rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

start = time.time()
#%%
modelo = 'CNN1D'
modeltype = 'v3'

modelpath = '/CNN1D-v3_results/'

path = os.getcwd()+modelpath


#train_size = [358398, 100000]
#batch_size = [50,16]
fold = [0,1,2,3,4]
#pat = [7, 3, 1]

pat = 7
batch_size = 16

## File names
aurocs = [ [] for k in fold]
fpr = [[] for k in fold]
tpr = [[] for k in fold]


for k in fold:
    fname= path + modelo + '-fpr_list_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
    fname2= path + modelo + '-tpr_list_fold%d_batch%d_pat%d.csv'%(k,batch_size,pat)
    fname3= path + modelo +'-val_aurocs_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
    print(fname)
    fpr[k] = pd.read_csv(fname, header=None)
    tpr[k] = pd.read_csv(fname2)
    fpr[k] = fpr[k].to_numpy()
    tpr[k] = tpr[k].to_numpy()    
    aurocs[k] = np.loadtxt(fname3)


#%%
# =============================================================================
# Loss validation
# =============================================================================

# Make the plot
## Define the plot range
fig, ax = plt.subplots(figsize=[7, 4])

plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
cor = 'black'

plt.title(r'Receiver Operating Characteristic: ' + modelo + modeltype, fontsize='20', color = cor)
ax.set_xlabel(r'False Positive Rate',fontsize=17, fontweight='bold',  color = cor)
ax.set_ylabel(r'True Positive Rate'  ,fontsize=17, fontweight='bold' ,  color = cor)

plt.plot([0, 1], [0, 1], color='black', lw=2, linestyle='--')


###plot
color=iter(plt.cm.hsv(np.linspace(0.1 ,1.,  len(fold))))

# -------------------------------------------------------
# # ### # all folds plots
# for k in fold:
#     c=next(color)
#     # plt.plot(fpr[k], tpr[k], color=c, lw=2,alpha = 1/(1 + k))
#     plt.plot(fpr[k], tpr[k], color=c, lw=2)
#     plt.plot(100,100, color=c, lw=2, label='ROC curve (area = %0.3f)' % auroc[k])
#              # alpha = 1/(1 + i))

def find_larger_array_length(arr1, arr2):
    len_arr1 = len(arr1)
    len_arr2 = len(arr2)
    
    if len_arr1 > len_arr2:
        return len_arr1
    else:
        return len_arr2

for i in range( len(fpr)):
    fpr_clean = fpr[0][i][~np.isnan(fpr[0][i])]
    tpr_clean = tpr[0][i][~np.isnan(tpr[0][i])]
    maxi = find_larger_array_length(fpr_clean,tpr_clean)
    print(maxi)
    
    print(tpr_clean.shape,fpr_clean.shape)
    # plt.plot(fpr_clean, tpr_clean[:-1], color='crimson', lw=2)
             # label='ROC curve (area = %0.3f)' % aurocs[i], alpha = 1/(1 + i))



# lb2 =  r'Model = CNN1D-v3'    
# lb0 =  r'Batch size = %d'%batch_size
# lb1 =  r'patience = %d'%patr_list

# ax.text(0.15*xmax, 0.95*ymax, lb2, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.89*ymax, lb0, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.956*ymax, lb1, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))

legend1 = ax.legend(loc="lower right", scatterpoints=1, fontsize=12, bbox_to_anchor=(1,0), framealpha=1, shadow=True)    
# 


## Ticks and color
plt.gca().spines['top'].set_color(cor)
plt.gca().spines['bottom'].set_color(cor)
plt.gca().spines['right'].set_color(cor)
plt.gca().spines['left'].set_color(cor)

ax.tick_params(axis='both', which='both', labelsize=14, direction="in", colors = cor)
ax.minorticks_on()

## get figure
fig1 = plt.gcf()
plt.show()
plt.draw()

## save pdf figure

# fig1.savefig('ROC_AVG_'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))

fig1.savefig('ROC_folds_'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))
