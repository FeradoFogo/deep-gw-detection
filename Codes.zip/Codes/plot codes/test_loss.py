
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 20 19:41:29 2023

@author: vitor
"""


from numba import njit
import time
import numpy as np
import glob
import os
import re
import sys
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition,mark_inset)
import matplotlib.pyplot as plt
import matplotlib.ticker
from matplotlib import rc
from scipy.ndimage import uniform_filter1d
from scipy import optimize
import matplotlib.lines as mlines


rc('font',**{'family':'serif','serif':['Helvetica']})
# for Palatino and other serif fonts use:
# rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

start = time.time()
#%%
modelo = 'CNN1D'
modeltype = 'v3'

modelpath = '/CNN1D-v3_results/'

path = os.getcwd()+modelpath


#train_size = [358398, 100000]
#batch_size = [50,16]
fold = [0,1,2,3,4]
#pat = [7, 3, 1]

pat = 7
batch_size = 16

## File names
valmetrics = [ [] for k in fold]
loss = [[] for k in fold]
loss_train = [[] for k in fold]


for k in fold:
    fname= path + modelo+'-val_losses_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
    fname2= path + modelo+'-train_losses_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
    print(fname)
    loss[k] = np.loadtxt(fname)
    loss_train[k] = np.loadtxt(fname2)
    
## avg and std
# Find the length of the longest array
max_len = max(len(arr) for arr in loss)
max_len2 = max(len(arr) for arr in loss_train)

# Pad arrays to the same length using np.nan
padded_arrays = [np.pad(arr, (0, max_len - len(arr)), mode='constant', constant_values=np.nan) for arr in loss]
padded_arrays2 = [np.pad(arr, (0, max_len - len(arr)), mode='constant', constant_values=np.nan) for arr in loss_train]

# Stack the padded arrays to create a 2D array
stacked_arrays = np.vstack(padded_arrays)
stacked_arrays2 = np.vstack(padded_arrays2)

# Compute the mean and standard deviation for each position (ignoring nan values)
mean = np.nanmean(stacked_arrays, axis=0)
mean2 = np.nanmean(stacked_arrays2, axis=0)
std = np.nanstd(stacked_arrays, axis=0)
std2 = np.nanstd(stacked_arrays2, axis=0)


#%%
# =============================================================================
# Loss validation
# =============================================================================

# Make the plot
## Define the plot range
fig, ax = plt.subplots(figsize=[7, 4])


xmin = 0.85
xmax = 15
ymin = 0.3
ymax = 0.9

cor = 'black'


ax.axis([xmin, xmax, ymin ,ymax])
plt.title(r'Loss: ' + modelo + modeltype, fontsize='20', color = cor)
ax.set_xlabel(r'Epochs',fontsize=17, fontweight='bold',  color = cor)
ax.set_ylabel(r' Loss'  ,fontsize=17, fontweight='bold' ,  color = cor)


###plot
color=iter(plt.cm.hsv(np.linspace(0.1 ,1.,  len(fold))))

# -------------------------------------------------------
# ### # all folds plots
# for k in fold:
#     c=next(color)
#     xacc = list(range(1,len(loss[k])+1))
#     print(xacc)
#     ax.plot(xacc,loss[k], '-o',c = c, lw = 2.5,  markerfacecolor=c, markeredgecolor='black', markeredgewidth=1.9, ms = 10)

#-------------------------------------------------------

# # AVG and STD plot :  VALIDATION
c='r'
xacc = list(range(1,max_len+1))
print(xacc)
ax.plot(xacc,mean, '-o',c = c, lw = 2.5,  markerfacecolor=c, markeredgecolor='black', markeredgewidth=1.5, ms = 7, label='Validation')
plt.fill_between(xacc,mean-std, mean+std, alpha=0.2, color='r')

# # AVG and STD plot :  TRAIN
c='b'
xacc2 = list(range(1,max_len2+1))
print(xacc2)
ax.plot(xacc2,mean2, '-o',c = c, lw = 2.5,  markerfacecolor=c, markeredgecolor='black', markeredgewidth=1.5, ms = 7, label='Train')
plt.fill_between(xacc2,mean2-std2, mean2+std2, alpha=0.2, color='r')

#-------------------------------------------------------



# lb2 =  r'Model = CNN1D-v3'    
# lb0 =  r'Batch size = %d'%batch_size
# lb1 =  r'patience = %d'%pat

# ax.text(0.15*xmax, 0.95*ymax, lb2, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.89*ymax, lb0, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.956*ymax, lb1, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))

legend1 = ax.legend(loc="upper right", scatterpoints=1, fontsize=14, bbox_to_anchor=(1.0,1), framealpha=1, shadow=True)    
# 


## Ticks and color
plt.gca().spines['top'].set_color(cor)
plt.gca().spines['bottom'].set_color(cor)
plt.gca().spines['right'].set_color(cor)
plt.gca().spines['left'].set_color(cor)

ax.tick_params(axis='both', which='both', labelsize=14, direction="in", colors = cor)
ax.minorticks_on()

## get figure
fig1 = plt.gcf()
plt.show()
plt.draw()

## save pdf figure

fig1.savefig('LOSS_AVG_'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))

# fig1.savefig('LOSS_folds_'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))
















