#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 20 21:40:34 2023

@author: vitor
"""

from numba import njit
import time
import numpy as np
import glob
import os
import re
import sys
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition,mark_inset)
import matplotlib.pyplot as plt
import matplotlib.ticker
from matplotlib import rc
from scipy.ndimage import uniform_filter1d
from scipy import optimize
import matplotlib.lines as mlines


rc('font',**{'family':'serif','serif':['Helvetica']})
# for Palatino and other serif fonts use:
# rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

start = time.time()
#%%
modelo = 'CNN1d-v4-cuda'
modeltype = 'v4'

modelpath = '/CNN1D-v4_test/'

path = os.getcwd()+modelpath


#train_size = [358398, 100000]
#batch_size = [50,16]
fold = [3]
#pat = [7, 3, 1]

pat = 3
batch_size = 50
k=3
## File names
valmetrics = [ ]
fpr = []
tpr = []


# for k in fold:
fname= path + modelo + '-fpr_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
fname2= path + modelo + '-tpr_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
fname3= path + modelo +'-val_metrics_fold%d_batch%d_pat%d.txt'%(k,batch_size,pat)
print(fname)
fpr = np.loadtxt(fname)
tpr = np.loadtxt(fname2)
valmetrics = np.loadtxt(fname3)
    
auroc = valmetrics[2]

# for i in range(len(valmetrics)):
#     temp = valmetrics[i]
#     auroc.append(temp[-1])   
    
    
## avg and std
# Find the length of the longest array
# max_len = max(len(arr) for arr in fpr)
# max_len2 = max(len(arr) for arr in tpr)

# # Pad arrays to the same length using np.nan
# padded_arrays = [np.pad(arr, (0, max_len - len(arr)), mode='constant', constant_values=np.nan) for arr in fpr]
# padded_arrays2 = [np.pad(arr, (0, max_len - len(arr)), mode='constant', constant_values=np.nan) for arr in tpr]

# # Stack the padded arrays to create a 2D array
# stacked_arrays = np.vstack(padded_arrays)
# stacked_arrays2 = np.vstack(padded_arrays2)

# # Compute the mean and standard deviation for each position (ignoring nan values)
# mean_fpr = np.nanmean(stacked_arrays, axis=0)
# mean_tpr = np.nanmean(stacked_arrays2, axis=0)
# std_fpr = np.nanstd(stacked_arrays, axis=0)
# std_tpr = np.nanstd(stacked_arrays2, axis=0)


#%%
# =============================================================================
# Loss validation
# =============================================================================

# Make the plot
## Define the plot range
fig, ax = plt.subplots(figsize=[7, 4])

plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
cor = 'black'

plt.title(r'Receiver Operating Characteristic: Test CNN1D-v4' , fontsize='20', color = cor)
ax.set_xlabel(r'False Positive Rate',fontsize=17, fontweight='bold',  color = cor)
ax.set_ylabel(r'True Positive Rate'  ,fontsize=17, fontweight='bold' ,  color = cor)

plt.plot([0, 1], [0, 1], color='black', lw=2, linestyle='--')


###plot
color=iter(plt.cm.hsv(np.linspace(0.1 ,1.,  len(fold))))

# -------------------------------------------------------
# ### # all folds plots
c = 'r'
# plt.plot(fpr[k], tpr[k], color=c, lw=2,alpha = 1/(1 + k))
plt.plot(fpr, tpr, color=c, lw=2)
plt.plot(100,100, color=c, lw=2, label='ROC curve (area = %0.3f)' % auroc)
         # alpha = 1/(1 + i))


# lb2 =  r'Model = CNN1D-v3'    
# lb0 =  r'Batch size = %d'%batch_size
# lb1 =  r'patience = %d'%pat

# ax.text(0.15*xmax, 0.95*ymax, lb2, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.89*ymax, lb0, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))
# ax.text(0.72*xmax, 0.956*ymax, lb1, fontsize = 16, bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))

legend1 = ax.legend(loc="lower right", scatterpoints=1, fontsize=12, bbox_to_anchor=(1,0), framealpha=1, shadow=True)    

avg_loss = valmetrics[0]
accuracy = valmetrics[1]

textstr = f'Avg Loss: {avg_loss:.4f}\nAccuracy: {accuracy:.4f}'
props = dict(boxstyle='round', facecolor='lightgrey', alpha=0.5)
ax.text(0.7, 0.3, textstr, transform=plt.gca().transAxes, fontsize=14, verticalalignment='top',  bbox=dict(boxstyle="round",ec='dimgray',fc='whitesmoke'))


## Ticks and color
plt.gca().spines['top'].set_color(cor)
plt.gca().spines['bottom'].set_color(cor)
plt.gca().spines['right'].set_color(cor)
plt.gca().spines['left'].set_color(cor)

ax.tick_params(axis='both', which='both', labelsize=14, direction="in", colors = cor)
ax.minorticks_on()

## get figure
fig1 = plt.gcf()
plt.show()
plt.draw()

## save pdf figure

# fig1.savefig('ROCTEST_AVG_'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))

fig1.savefig('ROCTEST_folds_v4'+modelo+modeltype +'_BS%d_pat%d.pdf'%(batch_size, pat))
