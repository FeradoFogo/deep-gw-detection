# -*- coding: utf-8 -*-

## Install stuff:
#!pip -q install pycbc
#!pip install efficientnet_pytorch -qq

#----------------------------------------------------------------------------------------------------------
## Import the libraries

import time
start_time = time.time()  # Record start time

import numpy as np
import pandas as pd
from glob import glob

import random
import os
import sys

from scipy.signal import welch
from scipy.interpolate import interp1d
from scipy.signal import butter, filtfilt
from scipy.signal import get_window

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torch.utils.data import Subset
from torch.utils.data import Dataset
from tqdm import tqdm

from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import CosineAnnealingLR
from nnAudio.Spectrogram import CQT1992v2
from sklearn.metrics import roc_curve, auc

from scipy.signal import fftconvolve

device = torch.device("cuda:0")
print(torch.cuda.is_available())

#------------------------------------------------------------------------------------------------------------

# Accessing command-line arguments

batch_size_arg = int(sys.argv[1])  # Assuming batch size is the first argument
pat_arg = int(sys.argv[2])         # Assuming pat is the second argument
train_size_arg = int(sys.argv[3])  # Assuming train_size is the third argument
fold_arg = int(sys.argv[4])

    # Now you can use these values in your code
print('Batch Size:' + str(batch_size_arg))
print('Patience:' + str(pat_arg))
print('Train Size:' + str(train_size_arg))
print('Fold:' + str(fold_arg))	


#------------------------------------------------------------------------------------------------------------

"""## Building the dataframe"""

# Set seeds for Python, NumPy, and PyTorch
seed = 69
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False  # Set to False to ensure deterministic behavio
#-----------------

labels = pd.read_csv("/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/training_labels.csv")
# Building a dataframe with paths and IDs of .npy files
path = "/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/train/"

#fonti007/gw_kaggle/train
paths = glob(path + "*/*/*/*")

training_labels = labels

training_paths = glob(path + "*/*/*/*")
#print(training_paths)

ids = [path.split("/")[-1].split(".")[0] for path in training_paths]
paths_df = pd.DataFrame({"path":training_paths, "id": ids})
train_data = pd.merge(left=training_labels, right=paths_df, on="id")
#print(train_data.head(3))

#------------------------------------------------------------------------------------------------------------

"""## Clean the data"""

## Def utily functions
def whiten(strain, dt, method='cu'):
    # Apply a window function
    if method == 'hanning':
        window = np.hanning(len(strain))
    elif method == 'hamming':
        window = np.hamming(len(strain))
    elif method == 'blackman':
        window = np.blackman(len(strain))
    else:
        window = np.ones(len(strain))

    # Windowed strain
    windowed_strain = strain * window

    # Zero-padding
    padded_strain = np.pad(windowed_strain, (len(strain)//2,), 'constant')

    # Estimate the power spectral density (PSD)
    freqs, Pxx = welch(padded_strain, fs=1/dt, nperseg=4*fs)

    # Interpolate the PSD to match the data length
    psd = interp1d(freqs, Pxx)

    # Fourier Transform of the padded data
    strain_ft = np.fft.rfft(padded_strain)

    # Frequency array
    freqs = np.fft.rfftfreq(len(padded_strain), dt)

    # Whiten the data
    white_strain = strain_ft / np.sqrt(psd(freqs))
    white_strain = np.fft.irfft(white_strain, n=len(padded_strain))

    # Remove padding
    white_strain = white_strain[len(strain)//2:-len(strain)//2]

    return white_strain
    
    
## Define class to organize and clean the data (Q-transform at the end!)
class G2NetDataset(Dataset):
    def __init__(self, dataframe, base_path, fs, lowcut, highcut):
        self.dataframe = dataframe
        self.base_path = base_path
        self.fs = fs
        self.lowcut = lowcut
        self.highcut = highcut

    def __len__(self):
        return len(self.dataframe)

    def bandpass_filter(self, data):
        nyq = 0.5 * self.fs
        low = self.lowcut / nyq
        high = self.highcut / nyq
        b, a = butter(4, [low, high], btype='band')
        normalization = np.sqrt((high-low))
        return filtfilt(b, a, data)/normalization

    def preprocess_data(self, data):
        window = get_window(('tukey', 0.125), data.shape[1])
        data_windowed = data * window
        whitened_data = np.array([whiten(d, 1.0/fs) for d in data_windowed])
        filtered_data = np.array([self.bandpass_filter(d) for d in whitened_data])
        return filtered_data

# # nnAudio implementation
    def qtransform(self, data):
        qplanes = []
        # qtrans = CQT1992v2(sr=fs, fmin=20, fmax=1024, hop_length=32)
        # qtrans = CQT1992v2(sr=fs, fmin=20, hop_length=32, fmax=512, n_bins = 64, bins_per_octave=21)
        qtrans = CQT1992v2(sr=fs, fmin=20, fmax=512, window='flattop', bins_per_octave=24, filter_scale=0.25, hop_length=16,verbose=False)
        for i in range(len(data)):
            cqt_output = qtrans(torch.from_numpy(data[i]).float())
            qplanes.append(cqt_output.numpy())
        qplanes = np.array(qplanes)
        qplanes = np.squeeze(qplanes, axis=1)
        # print(qplanes.shape)
        return qplanes

    def __getitem__(self, idx):
        file_id = self.dataframe.iloc[idx]['id']
        path = f"{self.base_path}/{file_id[0]}/{file_id[1]}/{file_id[2]}/{file_id}.npy"
        data = np.load(path)
        data = self.preprocess_data(data)
        data = self.qtransform(data)
        label = self.dataframe.iloc[idx]['target']
        return torch.from_numpy(data).float(), torch.tensor(label).float()

print('---------------------------------------------')
print('--------- Cleaning data class ---------------')

#------------------------------------------------------------------------------------------------------------
"""## Validation"""

def evaluate_model(model, val_loader, device):
    model.eval()
    criterion = nn.BCEWithLogitsLoss()
    running_loss = 0.0
    total = 0
    correct = 0
    all_labels = []
    all_probabilities = []
    all_predictions = []  	

    with torch.no_grad():
        for inputs, labels in val_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            loss = criterion(outputs.squeeze(), labels)
            running_loss += loss.item()

            probabilities = torch.sigmoid(outputs).squeeze().cpu().numpy()
            preds = (probabilities > 0.5).astype(np.float32)
            all_labels.extend(labels.cpu().numpy())
            all_probabilities.extend(probabilities)
            all_predictions.extend(preds)

            total += labels.size(0)
            correct += (preds == labels.cpu().numpy()).sum()

    avg_loss = running_loss / len(val_loader)
    accuracy = correct / total
   
    # Calculate ROC curve and AUROC
    fpr, tpr, _ = roc_curve(all_labels, all_probabilities)
    auroc = auc(fpr, tpr)

    return avg_loss, accuracy, np.array(all_predictions), all_probabilities, all_labels, fpr, tpr, auroc

#------------------------------------------------------------------------------------------------------------
"""# Training function"""

pat = pat_arg

def train_model(model, train_loader, val_loader, num_epochs, device, save_path):
    train_losses, val_losses, val_accuracies, val_aurocs, tpr_list, fpr_list = [], [], [], [], [], []
    criterion = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.0001)
    scheduler = CosineAnnealingLR(optimizer, T_max=num_epochs)

    model.to(device)
    best_val_loss = float('inf')
    patience = pat  # Define your patience (number of epochs to wait after improvement stops)
    patience_counter = 0

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0
        for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs}", unit='batch'):
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs.squeeze(), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        scheduler.step()
        avg_loss = running_loss / len(train_loader)
        train_losses.append(avg_loss)

        #val_loss, val_acc, _, _ = evaluate_model(model, val_loader, device)
        val_loss, val_acc, _,  _, _, fpr, tpr, auroc = evaluate_model(model, val_loader, device)
        val_losses.append(val_loss)
        val_accuracies.append(val_acc)
        val_aurocs.append(auroc)
        fpr_list.append(fpr)
        tpr_list.append(tpr)
       
        print(f'Epoch {epoch+1}/{num_epochs}, Loss: {avg_loss:.4f}, Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}, Val AUROC: {auroc:.4f}')

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), save_path)
            print(f'Model saved at epoch {epoch+1}')
            patience_counter = 0  # Reset the counter if validation loss improves
        else:
            patience_counter += 1  # Increment the counter if no improvement

        if patience_counter >= patience:
            print(f'Early stopping triggered after epoch {epoch+1}')
            break  # Break the loop if patience limit is reached

    print('Finished Training')
    return train_losses, val_losses, val_accuracies, val_aurocs, tpr_list, fpr_list

print('---------------------------------------------')
print('--------- Traning function defined ---------------')

#------------------------------------------------------------------------------------------------------------
#Define and train the model

# Generate a random float between 1 and 2
random_sleep_time = random.uniform(1, 2)

print(f"Sleeping for {random_sleep_time:.2f} seconds")
time.sleep(random_sleep_time)
print("Awake now!")

## RESNET (transfer learning)
import torchvision.models as models
class ResNetModel(nn.Module):
    def __init__(self, resnet_type='resnet50', freeze_layers=True):
        super().__init__()
        if resnet_type == 'resnet18':
            self.net = models.resnet18(pretrained=True)
        elif resnet_type == 'resnet34':
            self.net = models.resnet34(pretrained=True)
        elif resnet_type == 'resnet50':
            self.net = models.resnet50(pretrained=True)
        elif resnet_type == 'resnet101':
            self.net = models.resnet101(pretrained=True)
        elif resnet_type == 'resnet152':
            self.net = models.resnet152(pretrained=True)
        else:
            raise ValueError("Invalid ResNet type. Choose from 'resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152'")
        
        n_features = self.net.fc.in_features
        self.net.fc = nn.Linear(in_features=n_features, out_features=1, bias=True)

        # Freeze layers if specified
        if freeze_layers:
            for param in self.net.parameters():
                param.requires_grad = False  # Freeze pre-trained layers

        n_features = self.net.fc.in_features

        # Modify fully connected layers (including dropout)
        self.net.fc = nn.Sequential(
            nn.Linear(n_features, 512),  # Customized architecture: additional layer
            nn.ReLU(),  # Add activation function for better non-linearity
            nn.Dropout(0.5),  # Add dropout for regularization
            nn.Linear(512, 1)  # Adapted for binary classification
        )

    def forward(self, x):
        out = self.net(x)
        return out

#------------------------------------------------------------------------------------------------------------
"""## Cross validation: K-Folding"""

# Setup parameters
base_path = "/panfs/jay/groups/6/csci5527/fonti007/gw_kaggle/train"
fs = 2048  # Sampling frequency
lowcut = 18.0  # Low cut-off frequency
highcut = 600.0  # High cut-off frequency
batch_size = batch_size_arg
modelo = 'RNET101'

print('Running '+modelo)


# Create the full dataset
full_train_dataset = G2NetDataset(dataframe=train_data, base_path=base_path, fs=fs, lowcut=lowcut, highcut=highcut)

#### Perform the K-folding cross-validation:
from sklearn.model_selection import KFold

# Parameters
k = 5  # Number of folds in KFold
num_epochs = 20
q = fold_arg #run only one fold

# select a small subset to run the code
ntest = train_size_arg
nvali = np.int64(ntest/5)

# Calculate the index for splitting (80% for training + validation, 20% for testing)
split_index = int(len(train_data) * 0.8)

# Split the data indices for non-test and test
non_test_indices = list(range(split_index))
test_indices = list(range(split_index, len(train_data)))

# KFold setup
kf = KFold(n_splits=k, shuffle=True, random_state=69)
def kfold_paral(q):

    # Store results
    fold_results = []

    for fold, (train_indices, val_indices) in enumerate(kf.split(non_test_indices)):

        if fold == q:

            print(f"Training on fold {fold+1}/{q}")

            train_indices = list(train_indices)
            val_indices = list(val_indices)

        # Take a small subset for each fold
            subset_train_indices = random.sample(train_indices, k=ntest)  # Adjust k to desired subset size for training
            subset_val_indices = random.sample(val_indices, k=nvali)  # Adjust k to desired subset size for validation

        # Create subset datasets
            train_subset = Subset(full_train_dataset, subset_train_indices)
            val_subset = Subset(full_train_dataset, subset_val_indices)

        # Create DataLoaders for the subsets
            train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True, num_workers=2)
            val_loader = DataLoader(val_subset, batch_size=batch_size, shuffle=False, num_workers=2)

        # Model setup for each fold
            model = ResNetModel(resnet_type='resnet101')
            model.to(device)

        # Modify save_path to include fold information
            weight_path = modelo+"_cluster_fold%d_batch%d_pat%d.pth"%(fold,batch_size,pat)        
            save_path = "/panfs/jay/groups/6/csci5527/fonti007/CNN2D_results_v2/"
		
        # Train and validate the model on this fold
            train_losses, val_losses, val_accuracies, val_aurocs, tpr_list, fpr_list = train_model(model, train_loader, val_loader, num_epochs, device, (save_path+weight_path))

        # Save fold evaluation metrics (TRAIN)
            np.savetxt( save_path+ modelo+ '-train_losses_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), train_losses)
            np.savetxt( save_path+ modelo+ '-val_losses_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), val_losses)
            np.savetxt( save_path+ modelo+ '-val_accuracies_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), val_accuracies)
            
            np.savetxt( save_path+ modelo+ '-val_aurocs_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), val_aurocs)
#            np.savetxt( save_path+ modelo+ '-tpr_list_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), tpr_list)
#            np.savetxt( save_path+ modelo+ '-fpr_list_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), fpr_list)                                    
            pd.DataFrame(tpr_list).to_csv( save_path+ modelo+ '-tpr_list_fold%d_batch%d_pat%d.csv'%(fold,batch_size,pat) ,index = 'False')
            pd.DataFrame(fpr_list).to_csv( save_path+ modelo+ '-fpr_list_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat) ,index = 'False')



        # Evaluate the model on this fold's validation data
            val_loss, val_acc, all_predictions,  all_probabilities, all_labels, fpr, tpr, auroc = evaluate_model(model, val_loader, device)

        # Save fold evaluation metrics
            np.savetxt( save_path+ modelo+ '-val_metrics_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), [val_loss, val_acc, auroc])
            np.savetxt( save_path+ modelo+ '-all_predictions_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_predictions)
            np.savetxt( save_path+ modelo+ '-all_labels_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_labels)
            
            np.savetxt( save_path+ modelo+ '-all_probabilities_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), all_probabilities)
            np.savetxt( save_path+ modelo+ '-fpr_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), fpr)                        
            np.savetxt( save_path+ modelo+ '-tpr_fold%d_batch%d_pat%d.txt'%(fold,batch_size,pat), tpr)
            
            print(f'Fold {fold+1}/{k} training concluded.')


import time
start_time = time.time()  # Record start time

kfold_paral(q)

end_time = time.time()  # Record end time
duration = end_time - start_time  # Calculate duration

print(f"Total time for processing: {duration} seconds")



print('---------------------------------------------')
print('---------  Training concluded :)  -----------')
#------------------------------------------------------------------------------------------------------------

end_time = time.time()  # Record end time

duration = end_time - start_time  # Calculate duration
print(f"Total time for execution: {duration} seconds")
